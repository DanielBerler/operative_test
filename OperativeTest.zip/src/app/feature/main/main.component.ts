import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, AbstractControl } from "@angular/forms";
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss']
})
export class MainComponent implements OnInit {
  originalColors = [{
    id: 1,
    name: 'Red',
    color: 'red'
  },
  {
    id:2,
    name: 'Blue',
    color: 'blue'
  },
  {
    id:3,
    name: 'White',
    color: 'white'
  },
  {
    id:4,
    name: 'Green',
    color: 'green'
  },
  {
    id:5,
    name: 'Yellow',
    color: 'yellow'
  }];
  colors = [{
    id: 1,
    name: 'Red',
    color: 'red'
  },
  {
    id:2,
    name: 'Blue',
    color: 'blue'
  },
  {
    id:3,
    name: 'White',
    color: 'white'
  },
  {
    id:4,
    name: 'Green',
    color: 'green'
  },
  {
    id:5,
    name: 'Yellow',
    color: 'yellow'
  }];
  selectedColorIndex:number = 0;
  newColorPopup:any;
  newColorForm:FormGroup;
  newColorFormSubmitted:boolean = false;
  events:string[] = [];

  constructor(private modalService: NgbModal, public formBuilder: FormBuilder) {
    this.newColorForm = this.formBuilder.group({
      name: ['', [Validators.required, uniqueValidator(this.originalColors)]],
      color: ['', [Validators.required]]
    })
  }

  ngOnInit(): void {
  }

  color_click_handler($event:any, colopopup:any, index:number) {
    $event.preventDefault();
    $event.stopPropagation();

    this.selectedColorIndex = index;
    this.modalService.open(colopopup);
  }

  random_click_handler() {
    let temp_index_array = [];

    for(let i=0;i<this.colors.length;i++) {
      if(i != this.selectedColorIndex) {
        temp_index_array.push(i);
      }
    }

    let random_index = Math.round(Math.random() * temp_index_array.length);

    this.colors[this.selectedColorIndex].color = this.originalColors[temp_index_array[random_index]].color;

    this.events.push('Update ' + this.colors[this.selectedColorIndex].id + ' to ' + this.colors[this.selectedColorIndex].color);
  }

  new_color_click_handler($event:any, newcolorpopup:any) {
    $event.preventDefault();
    $event.stopPropagation();

    this.newColorForm.reset();
    this.newColorFormSubmitted = false;
    this.newColorPopup = this.modalService.open(newcolorpopup);
  }

  new_color_submit_handler() {
    this.newColorFormSubmitted = true;

    if(!this.newColorForm.valid) {
      return;
    }

    let new_color = {
      id: this.colors.length + 1,
      name: this.newColorForm.value.name,
      color: this.newColorForm.value.color
    };

    this.colors.push(new_color);
    this.originalColors.push(new_color);

    this.events.push('New Color ' + new_color.name);

    (this.newColorPopup as NgbModalRef).close();
  }
}

function uniqueValidator(colors:any[]){
  return (control: AbstractControl):{[key: string]: boolean} | null => {

    for(let i=0;i<colors.length;i++) {
      if(colors[i].name == control.value) {
        return {'uniqueValidator': true}
      }
    }

    return null;
  };
}
